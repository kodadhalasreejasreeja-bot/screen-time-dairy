"""Bulk CSV import with per-row validation and an error log."""
import csv
import os
from datetime import datetime
from .analytics import fits_in_day
from .models import Entry
from .storage import next_id
from .validation import (ValidationError, validate_app, validate_category,
                         validate_date, validate_minutes, validate_notes)

REQUIRED = {"date", "app", "category", "minutes"}


def import_csv(path, existing, outdir="exports"):
    """Returns (new_entries, errors, error_log_path). Never raises on bad rows."""
    new, errors = [], []
    try:
        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            headers = {h.strip().lower() for h in (reader.fieldnames or [])}
            if not REQUIRED <= headers:
                missing = ", ".join(sorted(REQUIRED - headers))
                return [], [f"File header is missing column(s): {missing}"], None
            all_entries = list(existing)
            for line_no, row in enumerate(reader, start=2):
                row = {(k or "").strip().lower(): (v or "") for k, v in row.items()}
                try:
                    entry = Entry(next_id(all_entries), validate_date(row["date"]),
                                  validate_app(row["app"]), validate_category(row["category"]),
                                  validate_minutes(row["minutes"]), validate_notes(row.get("notes", "")))
                    if not fits_in_day(all_entries, entry.date, entry.minutes):
                        raise ValidationError("would push that day above 24 hours")
                except ValidationError as exc:
                    errors.append(f"Row {line_no}: {exc}  -> {row}")
                    continue
                new.append(entry)
                all_entries.append(entry)
    except (FileNotFoundError, IsADirectoryError):
        return [], [f"File not found: {path}"], None
    except (UnicodeDecodeError, csv.Error) as exc:
        return [], [f"Could not read file as CSV: {exc}"], None
    log_path = None
    if errors:
        os.makedirs(outdir, exist_ok=True)
        log_path = os.path.join(outdir, f"import_errors_{datetime.now():%Y%m%d_%H%M%S}.log")
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("\n".join(errors) + "\n")
    return new, errors, log_path
