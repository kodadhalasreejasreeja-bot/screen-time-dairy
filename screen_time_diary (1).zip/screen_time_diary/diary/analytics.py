"""Core business logic: totals, summaries, trends, search, warnings."""
from collections import defaultdict
from datetime import date, timedelta
from .validation import MAX_MINUTES_PER_ENTRY, fmt_duration

DAILY_LIMIT = 480        # minutes/day before a warning (8h)
ENTRY_LIMIT = 300        # single-session minutes considered anomalous (5h)


def daily_totals(entries):
    totals = defaultdict(int)
    for e in entries:
        totals[e.date] += e.minutes
    return dict(sorted(totals.items()))


def total_for(entries, day):
    return sum(e.minutes for e in entries if e.date == day)


def fits_in_day(entries, day, minutes):
    """A day only has 1440 minutes - reject entries that would exceed it."""
    return total_for(entries, day) + minutes <= MAX_MINUTES_PER_ENTRY


def group_minutes(entries, attr):
    out = defaultdict(int)
    for e in entries:
        out[getattr(e, attr)] += e.minutes
    return dict(sorted(out.items(), key=lambda kv: -kv[1]))


def compute_trend(daily):
    """Average of the latest 7 days vs the 7 days before (relative to latest logged day)."""
    if not daily:
        return {"direction": "n/a", "recent_avg": 0, "prior_avg": 0, "change_pct": 0}
    latest = date.fromisoformat(max(daily))

    def avg(start_off, end_off):
        vals = [daily[d] for d in daily
                if latest - timedelta(days=start_off) <= date.fromisoformat(d) <= latest - timedelta(days=end_off)]
        return sum(vals) / len(vals) if vals else None

    recent, prior = avg(6, 0), avg(13, 7)
    if recent is None or prior is None or prior == 0:
        return {"direction": "not enough data", "recent_avg": recent or 0,
                "prior_avg": prior or 0, "change_pct": 0}
    change = (recent - prior) / prior * 100
    direction = "rising" if change > 5 else "falling" if change < -5 else "steady"
    return {"direction": direction, "recent_avg": recent, "prior_avg": prior, "change_pct": change}


def status_for(avg_minutes):
    if avg_minutes <= 240:
        return "GOOD"
    if avg_minutes <= DAILY_LIMIT:
        return "MODERATE"
    return "HIGH"


def summarize(entries):
    if not entries:
        return None
    daily = daily_totals(entries)
    by_app, by_cat = group_minutes(entries, "app"), group_minutes(entries, "category")
    total = sum(daily.values())
    avg = total / len(daily)
    busiest = max(daily.items(), key=lambda kv: kv[1])
    return {"entries": len(entries), "total": total, "days": len(daily), "avg": avg,
            "busiest": busiest, "top_app": next(iter(by_app.items())),
            "top_category": next(iter(by_cat.items())),
            "by_app": by_app, "by_category": by_cat, "daily": daily,
            "trend": compute_trend(daily), "status": status_for(avg)}


def search(entries, keyword=None, category=None, start=None, end=None):
    kw = keyword.lower() if keyword else None
    result = []
    for e in entries:
        if kw and kw not in e.app.lower() and kw not in e.notes.lower():
            continue
        if category and e.category != category:
            continue
        if start and e.date < start:
            continue
        if end and e.date > end:
            continue
        result.append(e)
    return result


def find_warnings(entries, daily_limit=DAILY_LIMIT, entry_limit=ENTRY_LIMIT):
    msgs = []
    for day, mins in daily_totals(entries).items():
        if mins > daily_limit:
            msgs.append(f"{day}: daily total {fmt_duration(mins)} exceeds limit of {fmt_duration(daily_limit)}")
    for e in entries:
        if e.minutes >= entry_limit:
            msgs.append(f"{e.date}: long single session on {e.app} ({fmt_duration(e.minutes)}) - check for errors")
    return msgs
