"""Generate realistic sample data (CSV + JSON) and a messy legacy CSV for import demos.
Run:  python -m diary.seed
"""
import csv
import json
import os
import random
from datetime import date, timedelta

APPS = [("Instagram", "Social"), ("YouTube", "Entertainment"), ("VS Code", "Productivity"),
        ("WhatsApp", "Communication"), ("Duolingo", "Education"), ("Netflix", "Entertainment"),
        ("Chess.com", "Gaming"), ("Notion", "Productivity"), ("Coursera", "Education"),
        ("Phone", "Other"), ("Reddit", "Social")]


def build(days=21, seed=39):
    rng = random.Random(seed)
    today = date.today()
    rows, i = [], 1
    for off in range(days - 1, -1, -1):
        day = (today - timedelta(days=off)).isoformat()
        for app, cat in rng.sample(APPS, rng.randint(1, 3)):
            rows.append({"id": i, "date": day, "app": app, "category": cat,
                         "minutes": rng.choice([15, 25, 30, 45, 60, 90, 120]),
                         "notes": rng.choice(["", "", "commute", "lunch break", "evening"])})
            i += 1
    # boundary / edge cases
    edge = [(today - timedelta(days=30), "Phone", "Other", 1, "minimum value"),
            (today - timedelta(days=29), "Chess.com", "Gaming", 600, "marathon session (anomaly)"),
            (today - timedelta(days=28), "YouTube", "Entertainment", 1440, "boundary: full day"),
            (today - timedelta(days=27), "VS Code", "Productivity", 330, "hackathon prep"),
            (today - timedelta(days=26), "Notion", "Productivity", 540, "long work day")]
    for d, app, cat, m, note in edge:
        rows.append({"id": i, "date": d.isoformat(), "app": app, "category": cat, "minutes": m, "notes": note})
        i += 1
    return rows


def main():
    os.makedirs("data", exist_ok=True)
    rows = build()
    with open("data/sample_data.json", "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    with open("data/sample_data.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    today = date.today()
    legacy = [("date", "app", "category", "minutes", "notes"),
              ((today - timedelta(days=3)).isoformat(), "Spotify", "Entertainment", "40", "ok row"),
              ("31-12-2025", "Instagram", "Social", "20", "bad date format"),
              ((today - timedelta(days=2)).isoformat(), "", "Social", "20", "blank app"),
              ((today - timedelta(days=2)).isoformat(), "Slack", "Communication", "abc", "non-numeric"),
              ((today - timedelta(days=2)).isoformat(), "Slack", "Communication", "-5", "negative"),
              ((today - timedelta(days=1)).isoformat(), "Kindle", "Education", "35", "ok row"),
              ((today - timedelta(days=1)).isoformat(), "Kindle", "Hobbies", "35", "unknown category"),
              ((today + timedelta(days=5)).isoformat(), "Kindle", "Education", "35", "future date")]
    with open("data/legacy_import_sample.csv", "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(legacy)
    # default working file starts as a copy of the sample so the demo has data
    with open("data/screen_time.json", "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    print(f"Wrote {len(rows)} sample entries to data/ (sample_data.csv/json, screen_time.json, legacy_import_sample.csv)")


if __name__ == "__main__":
    main()
