"""Pure validators: take raw text, return a clean value or raise ValidationError."""
import re
from datetime import date, datetime

CATEGORIES = ["Social", "Entertainment", "Productivity", "Education",
              "Gaming", "Communication", "Other"]
MAX_MINUTES_PER_ENTRY = 1440      # minutes in a day
DATE_FMT = "%Y-%m-%d"


class ValidationError(ValueError):
    pass


def validate_date(text):
    text = (text or "").strip()
    if not text or text.lower() == "today":
        return date.today().isoformat()
    try:
        d = datetime.strptime(text, DATE_FMT).date()
    except ValueError:
        raise ValidationError("Use the format YYYY-MM-DD (e.g. 2026-11-21) or 'today'.")
    if d > date.today():
        raise ValidationError("Date cannot be in the future.")
    if d.year < 2000:
        raise ValidationError("Date is too far in the past (before 2000).")
    return d.isoformat()


def validate_app(text):
    text = (text or "").strip()
    if not text:
        raise ValidationError("App/device name cannot be blank.")
    if len(text) > 50:
        raise ValidationError("Name is too long (max 50 characters).")
    if not re.fullmatch(r"[\w .+&'\-]+", text):
        raise ValidationError("Name contains unsupported characters.")
    return text


def validate_minutes(text):
    text = (text or "").strip()
    if not text:
        raise ValidationError("Minutes cannot be blank.")
    try:
        value = int(text)
    except ValueError:
        raise ValidationError("Enter a whole number of minutes (e.g. 45).")
    if value < 1:
        raise ValidationError("Minutes must be at least 1.")
    if value > MAX_MINUTES_PER_ENTRY:
        raise ValidationError(f"Minutes cannot exceed {MAX_MINUTES_PER_ENTRY} (24 hours).")
    return value


def validate_category(text):
    text = (text or "").strip()
    if text.isdigit() and 1 <= int(text) <= len(CATEGORIES):
        return CATEGORIES[int(text) - 1]
    for c in CATEGORIES:
        if c.lower() == text.lower():
            return c
    raise ValidationError("Pick a category number or name from the list.")


def validate_notes(text):
    text = (text or "").strip()
    if len(text) > 200:
        raise ValidationError("Notes too long (max 200 characters).")
    return text


def validate_optional_date(text):
    """Blank -> None; otherwise a normal date."""
    if not (text or "").strip():
        return None
    return validate_date(text)


def fmt_duration(minutes):
    minutes = int(round(minutes))
    return f"{minutes // 60}h {minutes % 60:02d}m"
