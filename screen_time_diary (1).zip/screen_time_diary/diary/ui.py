"""Menu-driven terminal interface."""
import os
import sys
from . import analytics, importer, plotting, reports
from .models import Entry
from .storage import Storage, next_id
from .validation import (CATEGORIES, ValidationError, fmt_duration, validate_app,
                         validate_category, validate_date, validate_minutes,
                         validate_notes, validate_optional_date)

USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
PAGE_SIZE = 15


def c(text, code):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def ok(msg): print(c("✔ " + msg, "32"))
def warn(msg): print(c("⚠ " + msg, "33"))
def err(msg): print(c("✖ " + msg, "31"))


def ask(label, validator, default_hint=""):
    """Centralised input wrapper: loops until the validator accepts the value."""
    while True:
        raw = input(f"{label}{default_hint}: ")
        try:
            return validator(raw)
        except ValidationError as exc:
            err(str(exc))


def banner():
    print(c("╔══════════════════════════════════════════╗", "36"))
    print(c("║        SCREEN TIME DIARY  v1.0           ║", "36"))
    print(c("║   Log it. Sum it. Understand it.         ║", "36"))
    print(c("╚══════════════════════════════════════════╝", "36"))


def print_table(entries):
    if not entries:
        print("No matching entries.")
        return
    header = f"{'ID':>4}  {'Date':<10}  {'App/Device':<20}  {'Category':<13}  {'Time':>7}  Notes"
    rows = sorted(entries, key=lambda e: (e.date, e.id))
    for start in range(0, len(rows), PAGE_SIZE):
        print(c(header, "1"))
        print("-" * 80)
        for e in rows[start:start + PAGE_SIZE]:
            print(f"{e.id:>4}  {e.date:<10}  {e.app[:20]:<20}  {e.category:<13}  "
                  f"{fmt_duration(e.minutes):>7}  {e.notes[:25]}")
        shown = min(start + PAGE_SIZE, len(rows))
        print(f"-- showing {shown} of {len(rows)} --")
        if shown < len(rows):
            if input("Press Enter for next page (q to stop): ").strip().lower() == "q":
                break


class App:
    def __init__(self, path="data/screen_time.json"):
        self.store = Storage(path)
        self.entries = self.store.load()

    # ---- actions ----
    def log_entry(self):
        print(c("\n-- Log screen time --", "1"))
        day = ask("Date (YYYY-MM-DD, Enter = today)", validate_date)
        app = ask("App / device", validate_app)
        for i, cat in enumerate(CATEGORIES, 1):
            print(f"  {i}. {cat}")
        cat = ask("Category (number or name)", validate_category)
        while True:
            mins = ask("Minutes spent", validate_minutes)
            if analytics.fits_in_day(self.entries, day, mins):
                break
            err(f"{day} already has {fmt_duration(analytics.total_for(self.entries, day))} logged; "
                "a day cannot exceed 24h.")
        notes = ask("Notes (optional)", validate_notes)
        self.entries.append(Entry(next_id(self.entries), day, app, cat, mins, notes))
        self.store.save(self.entries)
        ok(f"Saved. Total for {day}: {fmt_duration(analytics.total_for(self.entries, day))}")
        if analytics.total_for(self.entries, day) > analytics.DAILY_LIMIT:
            warn("Daily limit exceeded for this day!")

    def view_all(self):
        print_table(self.entries)

    def do_search(self):
        print(c("\n-- Search --  (leave a field blank to skip it)", "1"))
        kw = input("Keyword (app or notes): ").strip() or None
        cat = None
        raw = input(f"Category ({', '.join(CATEGORIES)}): ").strip()
        if raw:
            try:
                cat = validate_category(raw)
            except ValidationError as exc:
                err(str(exc) + " Ignoring category filter.")
        start = ask("From date", validate_optional_date, " (blank = any)")
        end = ask("To date", validate_optional_date, " (blank = any)")
        print_table(analytics.search(self.entries, kw, cat, start, end))

    def day_summary(self):
        day = ask("Date (Enter = today)", validate_date)
        todays = [e for e in self.entries if e.date == day]
        print_table(todays)
        if todays:
            print(c(f"Total for {day}: {fmt_duration(sum(e.minutes for e in todays))}", "1"))

    def executive_summary(self):
        print(c("\n== Executive Summary ==", "1"))
        for line in reports.summary_lines(self.entries):
            print(" " + line)
        s = analytics.summarize(self.entries)
        if s:
            print(c("\n Time by category", "1"))
            top = max(s["by_category"].values())
            for k, v in s["by_category"].items():
                print(f"  {k:<14} {fmt_duration(v):>8}  {'█' * max(1, int(20 * v / top))}")
        warnings = analytics.find_warnings(self.entries)
        if warnings:
            print(c(f"\n Warnings ({len(warnings)})", "33"))
            for w in warnings[:10]:
                warn(w)
            if len(warnings) > 10:
                print(f"  ... and {len(warnings) - 10} more (see exported report)")

    def charts(self):
        paths = plotting.plot_all(self.entries)
        if paths is None:
            warn("Matplotlib is not installed. Run: pip install matplotlib")
        elif not paths:
            warn("Nothing to plot yet.")
        else:
            ok("Charts saved:")
            for p in paths:
                print("  " + p)

    def export(self):
        ok("Markdown report : " + reports.export_markdown(self.entries))
        ok("Text audit log  : " + reports.export_text(self.entries))
        ok("CSV export      : " + reports.export_csv(self.entries))

    def import_data(self):
        path = input("Path to CSV (columns: date,app,category,minutes,notes): ").strip().strip('"')
        new, errors, log = importer.import_csv(path, self.entries)
        if new:
            self.entries.extend(new)
            self.store.save(self.entries)
        ok(f"Imported {len(new)} row(s).")
        if errors:
            warn(f"{len(errors)} problem(s) found:")
            for line in errors[:5]:
                print("  " + line)
            if log:
                print(f"  Full row-by-row log: {log}")

    def delete(self):
        try:
            eid = int(input("Entry ID to delete: ").strip())
        except ValueError:
            err("Please enter a numeric ID.")
            return
        match = [e for e in self.entries if e.id == eid]
        if not match:
            err("No entry with that ID.")
        elif input(f"Delete #{eid} ({match[0].app}, {match[0].date})? [y/N]: ").strip().lower() == "y":
            self.entries.remove(match[0])
            self.store.save(self.entries)
            ok("Deleted.")

    # ---- main loop ----
    def run(self):
        banner()
        for w in self.store.warnings:
            warn(w)
        print(f"Loaded {len(self.entries)} entries from {self.store.path}")
        menu = [("1", "Log screen time", self.log_entry), ("2", "View all entries", self.view_all),
                ("3", "Search / filter", self.do_search), ("4", "Daily summary", self.day_summary),
                ("5", "Executive summary", self.executive_summary), ("6", "Generate charts", self.charts),
                ("7", "Export reports (MD / TXT / CSV)", self.export),
                ("8", "Bulk import from CSV", self.import_data), ("9", "Delete an entry", self.delete)]
        actions = {k: fn for k, _, fn in menu}
        while True:
            print(c("\nMAIN MENU", "1"))
            for k, label, _ in menu:
                print(f"  {k}. {label}")
            print("  0. Exit")
            try:
                choice = input("Choose an option: ").strip()
            except (EOFError, KeyboardInterrupt):
                choice = "0"
            if choice == "0":
                print("Goodbye! Your data is saved.")
                return
            if choice not in actions:
                err("Invalid option - please choose a number from the menu.")
                continue
            try:
                actions[choice]()
            except (EOFError, KeyboardInterrupt):
                print("\nCancelled.")
            except OSError as exc:
                err(f"File problem: {exc}")


def main():
    App().run()
