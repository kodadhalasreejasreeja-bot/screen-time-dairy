from dataclasses import dataclass, asdict


@dataclass
class Entry:
    id: int
    date: str        # YYYY-MM-DD
    app: str
    category: str
    minutes: int
    notes: str = ""

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, d):
        return cls(id=int(d["id"]), date=str(d["date"]), app=str(d["app"]),
                   category=str(d["category"]), minutes=int(d["minutes"]),
                   notes=str(d.get("notes", "")))
