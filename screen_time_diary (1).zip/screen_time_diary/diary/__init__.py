"""Screen Time Diary - log app/device time and summarise daily totals."""
__version__ = "1.0.0"
