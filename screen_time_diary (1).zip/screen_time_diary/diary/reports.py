"""Summary text plus Markdown / plain-text / CSV export."""
import csv
import os
from datetime import datetime
from .analytics import DAILY_LIMIT, find_warnings, summarize
from .validation import fmt_duration


def summary_lines(entries):
    s = summarize(entries)
    if not s:
        return ["No entries yet."]
    t = s["trend"]
    lines = [
        f"Entries logged     : {s['entries']} across {s['days']} day(s)",
        f"Total screen time  : {fmt_duration(s['total'])}",
        f"Average per day    : {fmt_duration(s['avg'])}  (limit {fmt_duration(DAILY_LIMIT)})",
        f"Busiest day        : {s['busiest'][0]} ({fmt_duration(s['busiest'][1])})",
        f"Top app/device     : {s['top_app'][0]} ({fmt_duration(s['top_app'][1])})",
        f"Top category       : {s['top_category'][0]} ({fmt_duration(s['top_category'][1])})",
        f"Status             : {s['status']}",
    ]
    if t["direction"] in ("rising", "falling", "steady"):
        lines.append(f"7-day trend        : {t['direction']} ({t['change_pct']:+.1f}% vs previous 7 days; "
                     f"{fmt_duration(t['recent_avg'])} vs {fmt_duration(t['prior_avg'])}/day)")
    else:
        lines.append("7-day trend        : not enough data yet")
    return lines


def _stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def export_markdown(entries, outdir="exports"):
    s = summarize(entries)
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, f"report_{_stamp()}.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Screen Time Diary Report\n\n")
        f.write(f"_Generated {datetime.now():%Y-%m-%d %H:%M}_\n\n## Summary\n\n")
        for line in summary_lines(entries):
            f.write(f"- {line}\n")
        if s:
            f.write("\n## Time by Category\n\n| Category | Time |\n|---|---|\n")
            for k, v in s["by_category"].items():
                f.write(f"| {k} | {fmt_duration(v)} |\n")
            f.write("\n## Daily Totals\n\n| Date | Time |\n|---|---|\n")
            for k, v in s["daily"].items():
                f.write(f"| {k} | {fmt_duration(v)} |\n")
        warns = find_warnings(entries)
        f.write("\n## Warnings\n\n")
        f.write("\n".join(f"- {w}" for w in warns) + "\n" if warns else "None.\n")
    return path


def export_text(entries, outdir="exports"):
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, f"audit_{_stamp()}.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"SCREEN TIME DIARY AUDIT LOG - {datetime.now():%Y-%m-%d %H:%M}\n" + "=" * 60 + "\n")
        f.write("\n".join(summary_lines(entries)) + "\n\nWARNINGS\n" + "-" * 60 + "\n")
        warns = find_warnings(entries)
        f.write("\n".join(warns) + "\n" if warns else "None\n")
        f.write("\nALL ENTRIES\n" + "-" * 60 + "\n")
        for e in sorted(entries, key=lambda x: (x.date, x.id)):
            f.write(f"#{e.id:<4} {e.date}  {e.app:<20} {e.category:<14} {e.minutes:>5} min  {e.notes}\n")
    return path


def export_csv(entries, outdir="exports"):
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, f"entries_{_stamp()}.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "date", "app", "category", "minutes", "notes"])
        for e in sorted(entries, key=lambda x: (x.date, x.id)):
            w.writerow([e.id, e.date, e.app, e.category, e.minutes, e.notes])
    return path
