"""Matplotlib charts. Falls back gracefully if matplotlib is not installed."""
import os
from .analytics import DAILY_LIMIT, daily_totals, group_minutes


def plot_all(entries, outdir="exports"):
    """Create trend, category and top-app charts. Returns list of file paths."""
    try:
        import matplotlib
        matplotlib.use("Agg")           # no display needed
        import matplotlib.pyplot as plt
    except ImportError:
        return None                      # caller shows a friendly message
    if not entries:
        return []
    os.makedirs(outdir, exist_ok=True)
    paths = []

    daily = daily_totals(entries)
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(list(daily), [m / 60 for m in daily.values()], marker="o", color="#2b6cb0")
    ax.axhline(DAILY_LIMIT / 60, color="#c53030", linestyle="--", label="Daily limit")
    ax.set_title("Daily Screen Time Trend")
    ax.set_ylabel("Hours")
    ax.legend()
    ax.tick_params(axis="x", rotation=60)
    fig.tight_layout()
    paths.append(os.path.join(outdir, "trend.png"))
    fig.savefig(paths[-1], dpi=120)
    plt.close(fig)

    cats = group_minutes(entries, "category")
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(list(cats), [m / 60 for m in cats.values()], color="#38a169")
    ax.set_title("Time by Category")
    ax.set_ylabel("Hours")
    ax.tick_params(axis="x", rotation=30)
    fig.tight_layout()
    paths.append(os.path.join(outdir, "categories.png"))
    fig.savefig(paths[-1], dpi=120)
    plt.close(fig)

    apps = list(group_minutes(entries, "app").items())[:8]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.barh([a for a, _ in apps][::-1], [m / 60 for _, m in apps][::-1], color="#dd6b20")
    ax.set_title("Top Apps / Devices")
    ax.set_xlabel("Hours")
    fig.tight_layout()
    paths.append(os.path.join(outdir, "top_apps.png"))
    fig.savefig(paths[-1], dpi=120)
    plt.close(fig)
    return paths
