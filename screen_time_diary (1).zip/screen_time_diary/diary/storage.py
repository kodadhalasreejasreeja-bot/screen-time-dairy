"""Local JSON persistence with corruption handling and atomic writes."""
import json
import os
from .models import Entry


class Storage:
    def __init__(self, path="data/screen_time.json"):
        self.path = path
        self.warnings = []          # messages to show the user after load

    def load(self):
        self.warnings = []
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if not isinstance(raw, list):
                raise json.JSONDecodeError("Top level must be a list", "", 0)
        except FileNotFoundError:
            self.save([])
            self.warnings.append(f"No data file found - created a new one at {self.path}.")
            return []
        except (json.JSONDecodeError, UnicodeDecodeError):
            backup = self.path + ".corrupt"
            os.replace(self.path, backup)
            self.save([])
            self.warnings.append(f"Data file was corrupted. Backed up to {backup} and started fresh.")
            return []
        entries, skipped = [], 0
        for item in raw:
            try:
                entries.append(Entry.from_dict(item))
            except (KeyError, TypeError, ValueError):
                skipped += 1
        if skipped:
            self.warnings.append(f"Skipped {skipped} malformed record(s) while loading.")
        return entries

    def save(self, entries):
        folder = os.path.dirname(self.path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump([e.to_dict() for e in entries], f, indent=2)
        os.replace(tmp, self.path)          # atomic: never leaves half-written file


def next_id(entries):
    return max((e.id for e in entries), default=0) + 1
