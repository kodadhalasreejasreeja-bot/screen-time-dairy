"""Entry point:  python main.py"""
from diary.ui import main

if __name__ == "__main__":
    main()
