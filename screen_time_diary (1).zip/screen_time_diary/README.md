# Screen Time Diary

A beginner-friendly Python terminal app to log time spent on apps/devices and summarise daily totals.
Built for FutureReady Hack - Project #39 (Health & Wellbeing).

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt  # only needed for charts (matplotlib)
python -m diary.seed             # optional: regenerate sample data
python main.py
```
Requires Python 3.10+. Everything except charts uses the standard library only.

## Features
| Brief requirement | Where |
|---|---|
| Menu-driven terminal UI (ANSI colour, paginated tables) | `diary/ui.py` |
| Defensive input validation (dates, minutes 1-1440, names, categories, 24h/day cap) | `diary/validation.py` |
| Business logic: daily totals, summaries, 7-day trend, status | `diary/analytics.py` |
| JSON persistence, atomic writes, missing/corrupt file recovery | `diary/storage.py` |
| Keyword / category / date-range search | `analytics.search`, menu 3 |
| Executive summary | `diary/reports.py`, menu 5 |
| Matplotlib charts (trend, category, top apps) -> `exports/` | `diary/plotting.py`, menu 6 |
| Export Markdown / text audit log / CSV | `diary/reports.py`, menu 7 |
| Threshold warnings (daily > 8h, single session >= 5h) | `analytics.find_warnings` |
| Bulk CSV import with row-by-row error log | `diary/importer.py`, menu 8 |

Tune limits in `diary/analytics.py` (`DAILY_LIMIT`, `ENTRY_LIMIT`).

## Sample data (`data/`)
- `screen_time.json` - working file the app loads (46 seeded entries incl. edge cases: 1 min, 10h session, full 24h day)
- `sample_data.csv` / `sample_data.json` - same dataset in both formats
- `legacy_import_sample.csv` - messy file for the import demo (bad date, blank app, non-numeric, negative, unknown category, future date)

Sample dates are generated relative to the day you run `python -m diary.seed`, so re-run it before a demo to keep the "last 7 days" trend fresh.

## Demo script (matches the brief)
1. `python main.py` - show the welcome banner and menu.
2. Option 1: enter bad values (blank app, `abc` minutes, `9999`) to show validation, then a valid entry.
3. Option 5: executive summary with trend and warnings.
4. Option 6/7: generate charts and export reports (see `exports/`).
5. Option 0, relaunch, option 2 - the entry is still there (persistence).
6. Option 8 with `data/legacy_import_sample.csv` - show the error log.

## Tests
```bash
python -m unittest discover -s tests -t .
```

## Project layout
```
main.py            entry point
diary/             models, validation, storage, analytics, reports, plotting, importer, seed, ui
data/              sample + working data
tests/             unit tests
exports/           generated charts and reports
```

## Ideas for next steps
Tkinter/Textual front end, per-app daily limits, edit-entry option, weekly email-style summary.
