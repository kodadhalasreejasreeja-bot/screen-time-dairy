import os
import tempfile
import unittest
from diary import analytics, importer
from diary.models import Entry
from diary.storage import Storage
from diary.validation import (ValidationError, validate_app, validate_category,
                              validate_date, validate_minutes)


class ValidationTests(unittest.TestCase):
    def test_minutes(self):
        self.assertEqual(validate_minutes(" 45 "), 45)
        for bad in ["", "abc", "0", "-3", "1441", "2.5"]:
            with self.assertRaises(ValidationError):
                validate_minutes(bad)

    def test_date(self):
        self.assertEqual(validate_date("2025-01-31"), "2025-01-31")
        for bad in ["31-01-2025", "2999-01-01", "nope", "1990-01-01"]:
            with self.assertRaises(ValidationError):
                validate_date(bad)

    def test_app_and_category(self):
        self.assertEqual(validate_app("  VS Code "), "VS Code")
        with self.assertRaises(ValidationError):
            validate_app("   ")
        with self.assertRaises(ValidationError):
            validate_app("x" * 51)
        self.assertEqual(validate_category("2"), "Entertainment")
        self.assertEqual(validate_category("gaming"), "Gaming")
        with self.assertRaises(ValidationError):
            validate_category("9")


class LogicTests(unittest.TestCase):
    def setUp(self):
        self.e = [Entry(1, "2025-01-01", "A", "Social", 60), Entry(2, "2025-01-01", "B", "Gaming", 30),
                  Entry(3, "2025-01-02", "A", "Social", 500)]

    def test_daily_totals(self):
        self.assertEqual(analytics.daily_totals(self.e), {"2025-01-01": 90, "2025-01-02": 500})

    def test_summary_and_warning(self):
        s = analytics.summarize(self.e)
        self.assertEqual(s["total"], 590)
        self.assertEqual(s["top_app"][0], "A")
        self.assertTrue(analytics.find_warnings(self.e))

    def test_daily_cap(self):
        self.assertFalse(analytics.fits_in_day(self.e, "2025-01-02", 1000))
        self.assertTrue(analytics.fits_in_day(self.e, "2025-01-02", 100))

    def test_search(self):
        self.assertEqual(len(analytics.search(self.e, keyword="a", category="Social")), 2)
        self.assertEqual(len(analytics.search(self.e, start="2025-01-02")), 1)


class StorageTests(unittest.TestCase):
    def test_roundtrip_missing_and_corrupt(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "x.json")
            s = Storage(path)
            self.assertEqual(s.load(), [])            # missing -> created
            s.save([Entry(1, "2025-01-01", "A", "Social", 5)])
            self.assertEqual(Storage(path).load()[0].app, "A")
            with open(path, "w") as f:
                f.write("{not json")
            s2 = Storage(path)
            self.assertEqual(s2.load(), [])           # corrupt -> backup + fresh
            self.assertTrue(os.path.exists(path + ".corrupt"))
            self.assertTrue(s2.warnings)


class ImportTests(unittest.TestCase):
    def test_bad_rows_logged(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "in.csv")
            with open(p, "w") as f:
                f.write("date,app,category,minutes,notes\n2025-01-01,A,Social,10,ok\n"
                        "bad,A,Social,10,\n2025-01-01,A,Social,x,\n")
            new, errors, log = importer.import_csv(p, [], outdir=d)
            self.assertEqual((len(new), len(errors)), (1, 2))
            self.assertTrue(os.path.exists(log))
            self.assertEqual(importer.import_csv(os.path.join(d, "nope.csv"), [])[1][0][:14], "File not found")


if __name__ == "__main__":
    unittest.main()
